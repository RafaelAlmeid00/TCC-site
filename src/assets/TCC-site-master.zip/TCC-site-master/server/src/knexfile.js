/* eslint-disable no-undef */
module.exports = {
    development : {
        client : 'mysql2',
        connection: {
            host: 'mysqlserver.cpzldhdkowxy.us-east-2.rds.amazonaws.com',
            port: 3306,
            user: 'admin',
            password: '01020304',
            database: 'easypass',
        }
    }
}