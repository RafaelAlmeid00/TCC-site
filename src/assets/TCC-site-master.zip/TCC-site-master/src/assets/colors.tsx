const colors = {
  pm: "#1976d2",
  sc: "#30e09a",
  scsd: "#0fcd88",
  tc: "#834ae1",
  tcsd: "#ad7cff",
};

export default colors;
