import SectionRota1  from "./rotas/sectionRotas";


function BussRotas() {
    return(
        <>
            <SectionRota1/>
        </>
    )
}

export default BussRotas