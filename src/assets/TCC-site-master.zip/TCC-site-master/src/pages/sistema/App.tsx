import MenuLateral from '../../components/menu/menulateral'
import MenuSistema from '../../components/menu/menusistema'
import Homesistema from '../../components/sistema/home'

function Sistema() {
    

    return (
        <>
        <MenuLateral />
        <MenuSistema />
        <Homesistema />
        </>
    )
}

export default Sistema
