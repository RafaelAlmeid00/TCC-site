import { createContext } from 'react';
const ModalContext = createContext({} as any);
export default ModalContext;