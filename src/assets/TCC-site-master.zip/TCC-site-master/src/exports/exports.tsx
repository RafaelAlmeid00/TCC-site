
export default function localData() {
        const userData = localStorage.getItem('user')
        
        return userData
}
